
const firebaseConfig = {
  apiKey: "AIzaSyCBuACSWNacXwiujFeNq2I53A7lG6gaaHg",
  authDomain: "cybershield-89462.firebaseapp.com",
  projectId: "cybershield-89462",
  storageBucket: "cybershield-89462.firebasestorage.app",
  messagingSenderId: "616801744711",
  appId: "1:616801744711:web:8f5ad3582206da7b6efe62",
  measurementId: "G-8WPECLF1Y1"
};
firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.firestore();
