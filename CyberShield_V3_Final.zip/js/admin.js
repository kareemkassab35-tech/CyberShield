
const siteRef = db.collection('site').doc('main');
auth.onAuthStateChanged(u=>{
  document.getElementById('authBox').style.display = u ? 'none':'block';
  document.getElementById('adminPanel').style.display = u ? 'block':'none';
  if(u) loadSiteSettings();
});
async function login(){
  try{ await auth.signInWithEmailAndPassword(
    document.getElementById('email').value,
    document.getElementById('password').value
  ); document.getElementById('authMsg').textContent='تم الدخول'; }
  catch(e){ document.getElementById('authMsg').textContent='فشل: '+e.message; }
}
async function loadSiteSettings(){
  const s=await siteRef.get(); const d=s.exists?s.data():{};
  document.getElementById('siteNameInput').value=d.name||'CyberShield';
  document.getElementById('heroTitleInput').value=d.heroTitle||'';
  document.getElementById('heroDescInput').value=d.heroDesc||'';
}
async function uploadImg(inputId, field){
  const f = document.getElementById(inputId).files[0];
  if(!f) return alert('اختر ملفاً');
  try{ const up = await uploadToCloudinary(f); await siteRef.set({[field]:up.secure_url},{merge:true});
    document.getElementById('siteMsg').textContent='تم الرفع والحفظ: '+field;
  }catch(e){ document.getElementById('siteMsg').textContent='فشل: '+e.message; }
}
async function saveSite(){
  await siteRef.set({
    name: document.getElementById('siteNameInput').value,
    heroTitle: document.getElementById('heroTitleInput').value,
    heroDesc: document.getElementById('heroDescInput').value
  },{merge:true});
  document.getElementById('siteMsg').textContent='تم الحفظ';
}
