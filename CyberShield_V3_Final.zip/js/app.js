
const siteDocRef = db.collection('site').doc('main');
async function loadSite(){
  const s = await siteDocRef.get(); const d = s.exists ? s.data() : {};
  document.getElementById('siteName').textContent = d.name || 'CyberShield';
  const nb = document.getElementById('newsBox');
  nb.innerHTML = '<p>مرحباً بك في CyberShield — ابدأ من لوحة التحكم لإعداد المحتوى.</p>';
}
loadSite();
