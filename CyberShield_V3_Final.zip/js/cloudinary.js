
const CLOUD_NAME = "dwpqxbn2q";
const UPLOAD_PRESET = "ml_default";
async function uploadToCloudinary(file){
  const res = await fetch(`https://api.cloudinary.com/v1_1/${CLOUD_NAME}/auto/upload`, {
    method:'POST',
    body: (()=>{const f=new FormData(); f.append('file',file); f.append('upload_preset',UPLOAD_PRESET); return f;})()
  });
  if(!res.ok) throw new Error('Upload failed');
  return await res.json();
}
