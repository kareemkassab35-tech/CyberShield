
# CyberShield V3 (Static, GitHub Pages Ready)
- Public site (index.html) + Admin Panel (admin.html)
- Firebase Auth + Firestore
- Cloudinary unsigned upload (images/videos) via preset
- Tools: IP Lookup, Password Strength/Generator, Base64, SHA-256
- Arabic-first UI, no build step
