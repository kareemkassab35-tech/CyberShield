import Head from 'next/head'
import Link from 'next/link'

export default function Home(){
  return (
    <>
      <Head>
        <title>CyberShield — Protect yourself with knowledge</title>
        <meta name="description" content="CyberShield tools and tutorials — bilingual (EN/AR) cyber security utilities." />
      </Head>
      <section className="max-w-6xl mx-auto px-4 py-12">
        <h1 className="text-3xl font-extrabold">CyberShield</h1>
        <p className="mt-2 opacity-80">Protect yourself with knowledge — ادوات ومقالات في الأمن السيبراني بالعربي والإنجليزي</p>
        <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
          <Link href="/tools"><a className="p-4 border rounded">Tools</a></Link>
          <Link href="/blog"><a className="p-4 border rounded">Blog</a></Link>
          <Link href="/privacy-policy"><a className="p-4 border rounded">Privacy Policy</a></Link>
        </div>
      </section>
    </>
  )
}
