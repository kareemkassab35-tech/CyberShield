export default function Privacy(){ 
  return (
    <section className="max-w-6xl mx-auto px-4 py-8">
      <h1 className="font-bold">Privacy Policy</h1>
      <p className="mt-2">This is a short template. Replace with full policy before launching. Tools run client-side; we do not collect passwords or tokens.</p>
    </section>
  )
}
