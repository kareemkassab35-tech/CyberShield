import Head from 'next/head'
import dynamic from 'next/dynamic'
const ToolCard = dynamic(() => import('../components/ToolCard'))

export default function Tools(){
  return (
    <>
      <Head><title>Tools — CyberShield</title></Head>
      <section className="max-w-6xl mx-auto px-4 py-8 grid grid-cols-1 md:grid-cols-2 gap-6">
        <ToolCard title="Password Strength" description="Check password strength locally in browser" toolId="password" />
        <ToolCard title="Base64 Encode/Decode" description="Encode and decode text with Base64" toolId="base64" />
      </section>
    </>
  )
}
