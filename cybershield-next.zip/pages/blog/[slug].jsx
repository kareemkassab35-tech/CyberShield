import { useRouter } from 'next/router'
export default function Post(){
  const r = useRouter(); const { slug } = r.query;
  const content = {
    'intro-to-passwords': { title: 'Intro to Passwords / مقدمة عن كلمات المرور', body: 'Passwords must be unique and long. Use passphrases.\n\nكلمات المرور يجب أن تكون فريدة وطويلة.' },
    'base64-explained': { title: 'Base64 Explained / شرح Base64', body: 'Base64 is an encoding scheme used for safe transmission of binary data.\n\nBase64 هو نظام ترميز.' },
    'secure-your-account': { title: 'Secure Your Account / أمان حسابك', body: 'Enable 2FA, use unique passwords, and avoid public Wi-Fi for sensitive tasks.\n\nفعّل التحقق بخطوتين...' }
  }
  const post = content[slug] || { title: 'Not found', body: '...' }
  return (
    <section className="max-w-6xl mx-auto px-4 py-8">
      <h1 className="font-bold">{post.title}</h1>
      <article className="mt-4 whitespace-pre-line">{post.body}</article>
    </section>
  )
}
