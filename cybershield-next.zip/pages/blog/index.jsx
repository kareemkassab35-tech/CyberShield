import Link from 'next/link'
export default function BlogIndex(){
  const posts = [
    { slug: 'intro-to-passwords', title: 'Intro to Passwords / مقدمة عن كلمات المرور' },
    { slug: 'base64-explained', title: 'Base64 Explained / شرح Base64' },
    { slug: 'secure-your-account', title: 'Secure Your Account / أمان حسابك' }
  ]
  return (
    <section className="max-w-6xl mx-auto px-4 py-8">
      <h2 className="font-semibold mb-4">Blog</h2>
      <ul className="space-y-3">
        {posts.map(p => (
          <li key={p.slug}><Link href={`/blog/${p.slug}`}><a className="text-indigo-600">{p.title}</a></Link></li>
        ))}
      </ul>
    </section>
  )
}
