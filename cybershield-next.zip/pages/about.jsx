export default function About(){
  return (
    <section className="max-w-6xl mx-auto px-4 py-8">
      <h1 className="font-bold">About / من نحن</h1>
      <p className="mt-3">Project by Kareem Kassab. Add your contact details here.</p>
    </section>
  )
}
