import { useState } from 'react'

export default function ToolCard({ title, description, toolId }){
  const [open, setOpen] = useState(false)
  return (
    <div className="p-4 border rounded">
      <h3 className="font-semibold">{title}</h3>
      <p className="text-sm opacity-80">{description}</p>
      <div className="mt-3">
        <button onClick={() => setOpen(!open)} className="px-3 py-1 border rounded">Open</button>
      </div>
      {open && (
        <div className="mt-3">
          {toolId === 'password' && (
            <div>
              <input placeholder="Enter password" className="w-full p-2 border rounded" id="pw" />
              <div className="mt-2 text-sm opacity-80">Tool runs locally in your browser only.</div>
            </div>
          )}
          {toolId === 'base64' && (
            <div>
              <textarea placeholder="Enter text" className="w-full p-2 border rounded" rows={4} id="b64"></textarea>
              <div className="mt-2 text-sm opacity-80">Use encode/decode in browser.</div>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
