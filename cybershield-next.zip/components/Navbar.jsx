import Link from 'next/link'
export default function Navbar(){ 
  return (
    <header className="shadow-sm bg-white dark:bg-slate-900">
      <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="font-bold text-lg">CyberShield</div>
          <div className="hidden sm:block text-sm opacity-70">Protect yourself with knowledge / احمِ نفسك بالمعرفة</div>
        </div>
        <nav className="flex items-center gap-3">
          <Link href="/"><a className="px-2">Home</a></Link>
          <Link href="/tools"><a className="px-2">Tools</a></Link>
          <Link href="/blog"><a className="px-2">Blog</a></Link>
          <Link href="/about"><a className="px-2">About</a></Link>
        </nav>
      </div>
    </header>
  )
}
