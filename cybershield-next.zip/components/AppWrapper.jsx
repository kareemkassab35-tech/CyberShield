import React from 'react'
import Navbar from './Navbar'

export default function AppWrapper({ children }){
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-slate-900 text-slate-900 dark:text-white">
      <Navbar />
      <main>{children}</main>
      <footer className="border-t py-6 text-center">CyberShield © {new Date().getFullYear()}</footer>
    </div>
  )
}
