# CyberShield — Next.js Starter (Bilingual)

This is a starter project prepared for Kareem Kassab.

## Quick setup
1. Install dependencies: `npm install`
2. Run dev: `npm run dev`
3. Build: `npm run build`

## Deploy
1. Push to GitHub and import into Vercel (recommended).
2. Add custom domain in Vercel dashboard.
3. Apply for AdSense after DNS/Domain is live. Add AdSense script to pages/_document.jsx when approved.

## Important notes
- All tools are client-side only. Do NOT send secrets to servers.
- Replace privacy policy with a full text before applying to AdSense.

## What I prepared for you
- Next.js + Tailwind project ready to run
- Pages: Home, Tools, Blog, About, Privacy Policy
- Simple Tool placeholders (Password, Base64)

If you want, I can now guide you step-by-step to:
- Create a Vercel project and deploy
- Buy and connect a domain
- Apply and setup AdSense

